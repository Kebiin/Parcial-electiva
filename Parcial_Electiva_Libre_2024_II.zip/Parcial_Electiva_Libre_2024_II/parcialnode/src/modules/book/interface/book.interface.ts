export interface BookInfo {
    title: string;
    author: string;
    publicationDate: Date;
    isbn: string;
    genre: string;
}
